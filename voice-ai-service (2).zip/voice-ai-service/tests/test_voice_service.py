from __future__ import annotations

import io
import math
import shutil
import struct
import wave
from pathlib import Path
from types import SimpleNamespace

import pytest

from backend.app.services.voice_service import VoiceCloningRequiredError, VoiceService


SAMPLE_RATE = 22050


def wav_bytes(duration_seconds: float = 7.0, sample_rate: int = SAMPLE_RATE) -> bytes:
    buffer = io.BytesIO()
    with wave.open(buffer, 'wb') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        for index in range(int(duration_seconds * sample_rate)):
            value = int(7000 * math.sin(2 * math.pi * 220 * index / sample_rate))
            wav_file.writeframesraw(struct.pack('<h', value))
    return buffer.getvalue()


def write_wav(path: Path, duration_seconds: float = 0.2) -> None:
    path.write_bytes(wav_bytes(duration_seconds))


class Uploaded:
    def __init__(self, name: str, payload: bytes):
        self.filename = name
        self.file = io.BytesIO(payload)


class FakeXTTS:
    def __init__(self):
        self.calls = []

    def tts_to_file(self, **kwargs):
        self.calls.append(kwargs)
        write_wav(Path(kwargs['file_path']))


@pytest.mark.skipif(shutil.which('ffmpeg') is None, reason='ffmpeg is required')
def test_reference_audio_is_normalized_and_quality_gated(tmp_path):
    service = VoiceService(tmp_path / 'audio', tmp_path / 'profiles')
    metadata = service.register_samples(1, [Uploaded('speaker.wav', wav_bytes())])

    assert metadata['quality_status'] == 'ready'
    assert metadata['total_duration_seconds'] >= 6
    assert metadata['quality_reports'][0]['sample_rate'] == SAMPLE_RATE
    assert metadata['quality_reports'][0]['channels'] == 1


def test_python_preprocessing_is_preferred_when_available(tmp_path, monkeypatch):
    service = VoiceService(tmp_path / 'audio', tmp_path / 'profiles')
    source = tmp_path / 'source.wav'
    target = tmp_path / 'processed.wav'
    source.write_bytes(b'placeholder')

    def fake_python_preprocessing(source_path, target_path):
        assert source_path == source
        target_path.write_bytes(b'processed')
        return target_path

    monkeypatch.setattr(service, '_preprocess_audio_python', fake_python_preprocessing)

    assert service._prepare_audio(source, target) == target
    assert target.read_bytes() == b'processed'


def test_xtts_is_used_and_model_is_cached(tmp_path):
    fake_model = FakeXTTS()
    factory_calls = []

    def factory():
        factory_calls.append(True)
        return fake_model

    profile_root = tmp_path / 'profiles'
    sample_dir = profile_root / 'voice_1' / 'versions' / 'v1' / 'processed'
    sample_dir.mkdir(parents=True)
    write_wav(sample_dir / 'sample_1.wav', duration_seconds=7)
    profile = SimpleNamespace(
        profile_name='mom_voice',
        sample_dir=sample_dir.as_posix(),
        consent_status='granted',
        is_ready=True,
    )
    service = VoiceService(tmp_path / 'audio', profile_root, xtts_factory=factory)

    first = service.generate_audio_result('Time for your medicine.', profile, require_cloned_voice=True)
    second = service.generate_audio_result('Please confirm once taken.', profile, require_cloned_voice=True)

    assert first.is_cloned is True
    assert first.provider == 'coqui-xtts-v2'
    assert second.is_cloned is True
    assert len(factory_calls) == 1
    assert fake_model.calls[0]['speaker_wav'] == [(sample_dir / 'sample_1.wav').as_posix()]


def test_require_cloned_voice_fails_instead_of_silent_fallback(tmp_path):
    service = VoiceService(tmp_path / 'audio', tmp_path / 'profiles')
    with pytest.raises(VoiceCloningRequiredError, match='voice_profile_not_selected'):
        service.generate_audio_result('Reminder text', require_cloned_voice=True)


def test_generated_audio_path_rejects_traversal(tmp_path):
    service = VoiceService(tmp_path / 'audio', tmp_path / 'profiles')
    assert service.resolve_audio_path('../secret.wav') is None


def test_profile_name_is_sanitized_before_output_path(tmp_path):
    service = VoiceService(tmp_path / 'audio', tmp_path / 'profiles')
    assert service._safe_artifact_name('../../patient/private') == 'patient_private'
