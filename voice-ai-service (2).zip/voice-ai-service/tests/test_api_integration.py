from pathlib import Path

from fastapi.testclient import TestClient

from backend.app.main import app
from backend.app.services.voice_service import AudioGenerationResult


def test_ai_reminder_uses_emotion_confidence_and_reports_fallback(monkeypatch):
    monkeypatch.setattr(
        'backend.app.routes.ai_reminders.voice_service.generate_audio_result',
        lambda **kwargs: AudioGenerationResult(None, 'unavailable', False, 'voice_profile_not_selected'),
    )
    with TestClient(app) as client:
        response = client.post('/ai-reminders/generate', json={
            'patient_name': 'John',
            'medication_name': 'Metformin',
            'dose': '500 mg',
            'mood': 'neutral',
            'primary_emotion': 'fear',
            'emotion_confidence': 0.95,
            'generate_audio': True,
            'llm_mode': 'template',
        })

    assert response.status_code == 200
    payload = response.json()
    assert payload['emotion_used'] == 'anxious'
    assert payload['tone'] == 'calm'
    assert payload['cloned_voice_used'] is False
    assert payload['voice_fallback_reason'] == 'voice_profile_not_selected'


def test_audio_endpoint_rejects_path_traversal():
    with TestClient(app) as client:
        response = client.get('/ai-reminders/audio', params={'path': '../jog.db'})
    assert response.status_code == 404


def test_emotion_assessment_push_is_stored_and_normalized():
    with TestClient(app) as client:
        patient = client.post('/patients', json={'name': 'Emotion Integration Test'}).json()
        response = client.post(
            f"/emotion-integration/patients/{patient['id']}/assessments",
            json={
                'patient_id': 'external-77',
                'dominant_mood': 'neutral',
                'primary_emotion': 'sadness',
                'emotion_confidence': 0.93,
                'risk_level': 'Medium',
                'mood_scores': {'positive': 0.1, 'neutral': 0.3, 'negative': 0.6},
            },
        )
    assert response.status_code == 200
    assert response.json()['effective_emotion'] == 'sad'
    assert response.json()['source'] == 'emotion_api_push'


def test_revoked_consent_disables_voice_profile():
    with TestClient(app) as client:
        patient = client.post('/patients', json={'name': 'Consent Test'}).json()
        profile = client.post('/voice-profiles', data={
            'patient_id': patient['id'],
            'profile_name': 'consent_voice',
            'speaker_name': 'Authorized Speaker',
            'language': 'en',
            'consent_status': 'granted',
        }).json()
        response = client.patch(
            f"/voice-profiles/{profile['id']}/consent",
            json={'consent_status': 'revoked'},
        )
    assert response.status_code == 200
    assert response.json()['consent_status'] == 'revoked'
    assert response.json()['is_ready'] is False
