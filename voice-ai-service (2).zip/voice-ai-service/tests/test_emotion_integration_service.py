from sqlmodel import Session, SQLModel, create_engine
from sqlalchemy.pool import StaticPool

from backend.app.models import Patient
from backend.app.schemas import EmotionAssessmentPayload
from backend.app.services.emotion_integration_service import effective_emotion, store_assessment


def test_confident_primary_emotion_overrides_questionnaire_mood():
    assert effective_emotion('neutral', 'fear', 0.90) == 'anxious'


def test_low_confidence_emotion_falls_back_to_questionnaire_mood():
    assert effective_emotion('positive', 'fear', 0.20) == 'positive'


def test_store_assessment_persists_emotion_contract():
    engine = create_engine(
        'sqlite://',
        connect_args={'check_same_thread': False},
        poolclass=StaticPool,
    )
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        patient = Patient(name='John')
        session.add(patient)
        session.commit()
        session.refresh(patient)

        assessment = EmotionAssessmentPayload(
            patient_id='mood-team-123',
            dominant_mood='neutral',
            primary_emotion='fear',
            emotion_confidence=0.91,
            risk_level='Medium',
            mood_scores={'positive': 0.1, 'neutral': 0.4, 'negative': 0.5},
        )
        stored = store_assessment(session, patient.id, assessment, 'test')

        assert stored.primary_emotion == 'fear'
        assert stored.emotion_confidence == 0.91
        assert stored.external_patient_id == 'mood-team-123'
        assert '"negative": 0.5' in stored.mood_scores_json
