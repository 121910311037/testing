from datetime import datetime, time

from sqlalchemy.pool import StaticPool
from sqlmodel import Session, SQLModel, create_engine

from backend.app.models import Medication, Patient, ReminderSchedule
from backend.app.services.reminder_service import due_schedules


def test_due_schedule_uses_patient_timezone_and_returns_utc_due_time():
    engine = create_engine(
        'sqlite://',
        connect_args={'check_same_thread': False},
        poolclass=StaticPool,
    )
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        patient = Patient(name='John', timezone='America/Chicago')
        session.add(patient)
        session.commit()
        session.refresh(patient)
        medication = Medication(patient_id=patient.id, name='Metformin', dose='500 mg')
        session.add(medication)
        session.commit()
        session.refresh(medication)
        schedule = ReminderSchedule(medication_id=medication.id, reminder_time=time(8, 0))
        session.add(schedule)
        session.commit()

        due = due_schedules(session, datetime(2026, 8, 17, 13, 0))

    assert len(due) == 1
    assert due[0][2] == datetime(2026, 8, 17, 13, 0)
