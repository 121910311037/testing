from backend.app.services.llm_service import generate_dynamic_reminder


def test_dynamic_reminder_template_fallback_has_text_and_tone():
    result = generate_dynamic_reminder({
        'patient_name': 'John',
        'medication_name': 'Metformin',
        'dose': '500 mg',
        'instructions': 'Take after food',
        'dominant_mood': 'sad',
        'preferred_tone': 'supportive',
        'weekly_taken': 3,
        'weekly_missed': 0,
        'weekly_snoozed': 0,
    })
    assert result['reminder_text'] if 'reminder_text' in result else result['text']
    assert result['tone'] == 'calm'
    assert result['llm_provider_used']
