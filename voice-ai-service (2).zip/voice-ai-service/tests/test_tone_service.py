from backend.app.services.tone_service import mood_to_tone, normalize_tone


def test_normalize_tone():
    assert normalize_tone('calm') == 'calm'
    assert normalize_tone('unknown') == 'supportive'


def test_mood_to_tone():
    assert mood_to_tone('happy') == 'cheerful'
    assert mood_to_tone('anxious') == 'calm'
    assert mood_to_tone('neutral') == 'supportive'
    assert mood_to_tone('neutral', missed_count=2) == 'followup_firm'
