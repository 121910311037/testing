from backend.app.services.safety_service import validate_reminder_text, sanitize_reminder_text


def test_safety_blocks_dosage_change():
    result = validate_reminder_text("You should increase your medication dose today.")
    assert result.passed is False


def test_safety_allows_normal_reminder():
    result = validate_reminder_text("Hi John, it is time to take your medicine. Please confirm once taken.")
    assert result.passed is True


def test_sanitize_limits_length():
    text = "word " * 80
    cleaned = sanitize_reminder_text(text, max_words=10)
    assert len(cleaned.split()) <= 10
