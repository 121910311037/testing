#!/usr/bin/env bash
set -e
streamlit run frontend/app.py
