import os
import requests
import streamlit as st

API_BASE = os.getenv('JOG_API_BASE', 'http://localhost:8000')

st.set_page_config(page_title='JOG Voice AI Service', page_icon='🔊', layout='wide')
st.title('🔊 JOG Voice AI Service')
st.caption('Reusable loved-one voice profiles + mood-aware reminder generation + confirm/snooze loop')


def api_get(path: str):
    return requests.get(f'{API_BASE}{path}', timeout=30)


def api_post_json(path: str, payload: dict):
    return requests.post(f'{API_BASE}{path}', json=payload, timeout=30)


def api_post_form(path: str, data=None, files=None):
    return requests.post(f'{API_BASE}{path}', data=data, files=files, timeout=120)


patient_resp = api_get('/patients')
patients = patient_resp.json() if patient_resp.ok else []
patient_options = {f"{p['id']} - {p['name']}": p['id'] for p in patients}

voice_resp = api_get('/voice-profiles')
voice_profiles = voice_resp.json() if voice_resp.ok else []
voice_options = {f"{v['id']} - {v['profile_name']} ({v['speaker_name']})": v['id'] for v in voice_profiles}


tab1, tab2, tab3, tab4, tab5 = st.tabs(['Active Reminders', 'Voice Profiles', 'Create Patient/Medication', 'Record Mood', 'AI Reminder Demo'])

with tab1:
    st.subheader('Current reminders')
    response = api_get('/reminders/active')
    reminders = response.json() if response.ok else []

    if not reminders:
        st.info('No active reminders yet. The seeded demo reminder should appear about a minute after startup.')

    for reminder in reminders:
        with st.container(border=True):
            st.markdown(f"### {reminder['patient_name']} • {reminder['medication_name']} {reminder['dose']}")
            st.write(f"**Status:** {reminder['status']} | **Tone:** {reminder['tone_used']}")
            st.write(reminder['reminder_text'])
            if reminder.get('audio_url'):
                audio_resp = api_get(reminder['audio_url'])
                if audio_resp.ok:
                    st.audio(audio_resp.content)

            c1, c2, c3 = st.columns(3)
            if c1.button('✅ Taken', key=f"taken_{reminder['id']}"):
                api_post_json(f"/reminders/{reminder['id']}/action", {'action': 'taken'})
                st.rerun()
            if c2.button('⏰ Snooze 10m', key=f"snooze_{reminder['id']}"):
                api_post_json(f"/reminders/{reminder['id']}/action", {'action': 'snoozed', 'snooze_minutes': 10})
                st.rerun()
            if c3.button('❌ Missed', key=f"missed_{reminder['id']}"):
                api_post_json(f"/reminders/{reminder['id']}/action", {'action': 'missed'})
                st.rerun()

with tab2:
    st.subheader('Create reusable loved-one voice profiles')
    c1, c2 = st.columns(2)

    with c1:
        with st.form('voice_profile_form'):
            selected_patient = st.selectbox('Patient', list(patient_options.keys()) if patient_options else ['No patients'])
            profile_name = st.text_input('Profile name', 'mom_voice')
            speaker_name = st.text_input('Speaker display name', 'Mom')
            language = st.text_input('Language', 'en')
            notes = st.text_area('Notes', 'Loved-one voice profile for reminders')
            create_profile = st.form_submit_button('Create profile')
            if create_profile and patient_options:
                resp = api_post_form('/voice-profiles', data={
                    'patient_id': patient_options[selected_patient],
                    'profile_name': profile_name,
                    'speaker_name': speaker_name,
                    'language': language,
                    'consent_status': 'granted',
                    'notes': notes,
                })
                if resp.ok:
                    st.success(f"Created voice profile #{resp.json()['id']}")
                    st.rerun()
                else:
                    st.error(resp.text)

        st.markdown('---')
        st.markdown('#### Upload reference samples')
        upload_profile = st.selectbox('Voice profile', list(voice_options.keys()) if voice_options else ['No voice profiles'])
        uploaded_files = st.file_uploader(
            'Upload loved-one audio samples',
            type=['wav', 'mp3', 'm4a', 'mp4', 'ogg', 'flac'],
            accept_multiple_files=True,
        )
        if st.button('Process and attach samples') and voice_options and uploaded_files:
            files = [('files', (f.name, f.getvalue(), f.type or 'application/octet-stream')) for f in uploaded_files]
            resp = api_post_form(f"/voice-profiles/{voice_options[upload_profile]}/samples", files=files)
            if resp.ok:
                st.success('Samples uploaded and processed.')
                st.rerun()
            else:
                st.error(resp.text)

    with c2:
        st.markdown('#### Existing voice profiles')
        if not voice_profiles:
            st.info('No voice profiles yet.')
        for profile in voice_profiles:
            with st.container(border=True):
                st.write(f"**#{profile['id']} {profile['profile_name']}** — {profile['speaker_name']}")
                st.write(f"Samples: {profile['sample_count']} | Ready: {profile['is_ready']} | Quality: {profile['quality_status']}")
                st.write(f"Provider: {profile['provider']} | Consent: {profile['consent_status']}")
                if profile['notes']:
                    st.caption(profile['notes'])

        st.markdown('---')
        st.markdown('#### Preview tone rendering')
        preview_profile = st.selectbox('Preview profile', list(voice_options.keys()) if voice_options else ['No voice profiles'], key='preview_profile')
        preview_text = st.text_area('Preview text', "Hi John, it's time to take your medicine.")
        preview_tone = st.selectbox('Preview tone', ['supportive', 'calm', 'cheerful', 'neutral', 'followup_firm'])
        if st.button('Generate preview') and voice_options:
            resp = api_post_form(
                f"/voice-profiles/{voice_options[preview_profile]}/preview",
                data={'text': preview_text, 'tone': preview_tone},
            )
            if resp.ok:
                payload = resp.json()
                st.success(f"Generated with provider: {payload['provider_used']}")
                audio_resp = api_get(payload['audio_url'])
                if audio_resp.ok:
                    st.audio(audio_resp.content)
                st.code(payload['audio_path'])
            else:
                st.error(resp.text)

with tab3:
    st.subheader('Create a patient and medication')
    with st.form('patient_form'):
        name = st.text_input('Patient name', 'Jane Doe')
        tone = st.selectbox('Preferred tone', ['supportive', 'calm', 'followup_firm', 'cheerful', 'neutral'])
        caregiver = st.text_input('Caregiver email', '')
        submitted = st.form_submit_button('Create patient')
        if submitted:
            resp = api_post_json('/patients', {'name': name, 'preferred_tone': tone, 'caregiver_email': caregiver or None})
            if resp.ok:
                st.success(f"Created patient #{resp.json()['id']}")
                st.rerun()
            else:
                st.error(resp.text)

    with st.form('med_form'):
        selected_label = st.selectbox('Patient', list(patient_options.keys()) if patient_options else ['No patients'], key='med_patient')
        med_name = st.text_input('Medication name', 'Vitamin D')
        dose = st.text_input('Dose', '1 tablet')
        instructions = st.text_input('Instructions', 'Take after breakfast')
        refill = st.number_input('Refills remaining', min_value=0, value=3)
        reminder_hour = st.number_input('Reminder hour', min_value=0, max_value=23, value=8)
        reminder_min = st.number_input('Reminder minute', min_value=0, max_value=59, value=0)
        submitted_med = st.form_submit_button('Create medication + schedule')

        if submitted_med and patient_options:
            patient_id = patient_options[selected_label]
            med_resp = api_post_json('/patients/medications', {
                'patient_id': patient_id,
                'name': med_name,
                'dose': dose,
                'instructions': instructions,
                'refill_remaining': int(refill),
            })
            if med_resp.ok:
                med = med_resp.json()
                sched_resp = api_post_json('/patients/schedules', {
                    'medication_id': med['id'],
                    'reminder_time': f'{int(reminder_hour):02d}:{int(reminder_min):02d}:00',
                    'frequency': 'daily',
                    'enabled': True,
                    'snooze_minutes': 10,
                })
                if sched_resp.ok:
                    st.success('Medication and schedule created.')
                    st.rerun()
                else:
                    st.error(sched_resp.text)
            else:
                st.error(med_resp.text)

with tab4:
    st.subheader('Record current mood')
    mood_patient_options = {f"{p['id']} - {p['name']}": p['id'] for p in patients} if patients else {}
    with st.form('mood_form'):
        selected_label = st.selectbox('Patient for mood update', list(mood_patient_options.keys()) if mood_patient_options else ['No patients'])
        mood = st.selectbox('Dominant mood', ['positive', 'neutral', 'sad', 'anxious', 'negative', 'happy', 'angry'])
        summary = st.text_area('Mood summary', 'Patient reported feeling okay today.')
        submitted_mood = st.form_submit_button('Save mood')
        if submitted_mood and mood_patient_options:
            patient_id = mood_patient_options[selected_label]
            resp = api_post_json('/patients/moods', {
                'patient_id': patient_id,
                'source': 'manual_ui',
                'dominant_mood': mood,
                'summary': summary,
            })
            if resp.ok:
                st.success('Mood saved. Future reminders will use this tone context.')
            else:
                st.error(resp.text)


with tab5:
    st.subheader('AI Dynamic Reminder Demo')
    st.caption('Flow: mood/context → Llama/template reminder text → tone mapping → selected voice profile → audio.')

    demo_profile = st.selectbox('Optional voice profile', ['Use default fallback voice'] + list(voice_options.keys()), key='ai_demo_profile')
    c1, c2 = st.columns(2)
    with c1:
        demo_patient = st.text_input('Patient name', 'John')
        demo_med = st.text_input('Medication', 'Metformin')
        demo_dose = st.text_input('Dose', '500 mg')
        demo_instructions = st.text_input('Instructions', 'Take after food')
    with c2:
        demo_llm_mode = st.selectbox('LLM provider', ['ollama', 'template', 'huggingface'], help='Use ollama for local Llama 3.1. Template is the stable fallback.')
        demo_mood = st.selectbox('Mood/context', ['neutral', 'sad', 'anxious', 'negative', 'happy', 'positive', 'angry', 'irritated'])
        demo_preferred_tone = st.selectbox('Preferred tone', ['supportive', 'calm', 'cheerful', 'neutral', 'followup_firm'])
        missed = st.number_input('Missed reminders this week', min_value=0, max_value=10, value=0)
        taken = st.number_input('Taken reminders this week', min_value=0, max_value=50, value=3)

    if st.button('Generate dynamic AI reminder'):
        voice_profile_id = None
        if demo_profile != 'Use default fallback voice':
            voice_profile_id = voice_options[demo_profile]
        payload = {
            'patient_name': demo_patient,
            'medication_name': demo_med,
            'dose': demo_dose,
            'instructions': demo_instructions,
            'mood': demo_mood,
            'preferred_tone': demo_preferred_tone,
            'weekly_taken': int(taken),
            'weekly_missed': int(missed),
            'weekly_snoozed': 0,
            'voice_profile_id': voice_profile_id,
            'generate_audio': True,
            'llm_mode': demo_llm_mode,
        }
        resp = api_post_json('/ai-reminders/generate', payload)
        if resp.ok:
            result = resp.json()
            st.success('Dynamic reminder generated')
            st.write(f"**LLM provider:** {result['llm_provider_used']}")
            st.write(f"**Tone selected:** {result['tone']}")
            st.write(result['reminder_text'])
            if result.get('audio_url'):
                audio_resp = api_get(result['audio_url'])
                if audio_resp.ok:
                    st.audio(audio_resp.content)
            st.json(result)
        else:
            st.error(resp.text)
