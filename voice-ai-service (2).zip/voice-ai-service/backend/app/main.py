from contextlib import asynccontextmanager
from datetime import datetime
import asyncio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import Session
from .config import settings
from .database import engine, init_db
from .routes.patients import router as patients_router
from .routes.reminders import router as reminders_router
from .routes.voice_profiles import router as voice_profiles_router
from .routes.ai_reminders import router as ai_reminders_router
from .services.bootstrap_service import seed_demo
from .services.reminder_service import due_schedules, create_event_for_due_schedule


async def reminder_loop() -> None:
    while True:
        try:
            with Session(engine) as session:
                now = datetime.now()
                for schedule, medication in due_schedules(session, now):
                    create_event_for_due_schedule(session, schedule, medication, now)
        except Exception as exc:
            print(f'Reminder loop error: {exc}')
        await asyncio.sleep(settings.reminder_poll_seconds)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    with Session(engine) as session:
        seed_demo(session)
    task = asyncio.create_task(reminder_loop())
    yield
    task.cancel()


app = FastAPI(title=settings.app_name, lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in settings.allowed_origins.split(',') if origin.strip()],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(patients_router)
app.include_router(reminders_router)
app.include_router(voice_profiles_router)
app.include_router(ai_reminders_router)


@app.get('/')
def root():
    return {
        'app': settings.app_name,
        'status': 'running',
        'llm_mode': settings.llm_mode,
        'message': 'Open /docs for API docs or run the Streamlit frontend.',
    }
