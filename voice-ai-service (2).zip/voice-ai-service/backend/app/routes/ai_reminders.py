from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlmodel import Session

from ..config import AUDIO_DIR
from ..database import get_session
from ..models import VoiceProfile
from ..schemas import AIReminderRequest, AIReminderResponse
from ..services.llm_service import generate_dynamic_reminder
from ..services.voice_service import voice_service

router = APIRouter(prefix='/ai-reminders', tags=['ai-reminders'])


@router.post('/generate', response_model=AIReminderResponse)
def generate_ai_reminder(payload: AIReminderRequest, session: Session = Depends(get_session)):
    """Generate dynamic reminder text and optionally render it as audio.

    This endpoint restores the notebook flow in product form:
    mood/context -> LLM/template reminder text -> tone -> selected voice profile -> audio.
    """
    context = {
        'patient_name': payload.patient_name,
        'medication_name': payload.medication_name,
        'dose': payload.dose,
        'instructions': payload.instructions,
        'dominant_mood': payload.mood,
        'preferred_tone': payload.preferred_tone,
        'weekly_taken': payload.weekly_taken,
        'weekly_missed': payload.weekly_missed,
        'weekly_snoozed': payload.weekly_snoozed,
    }
    llm_result = generate_dynamic_reminder(context, llm_mode=payload.llm_mode)

    audio_path = None
    audio_url = None
    voice_provider_used = None
    voice_profile = None

    if payload.generate_audio:
        if payload.voice_profile_id is not None:
            voice_profile = session.get(VoiceProfile, payload.voice_profile_id)
            if not voice_profile:
                raise HTTPException(status_code=404, detail='Voice profile not found')

        audio_path, voice_provider_used = voice_service.generate_audio(
            text=llm_result['text'],
            voice_profile=voice_profile,
            tone=llm_result['tone'],
            language=getattr(voice_profile, 'language', 'en') if voice_profile else 'en',
        )
        audio_url = f"/ai-reminders/audio?path={Path(audio_path).name}" if audio_path else None

    return AIReminderResponse(
        reminder_text=llm_result['text'],
        tone=llm_result['tone'],
        llm_provider_used=llm_result['llm_provider_used'],
        voice_profile_id=payload.voice_profile_id,
        voice_provider_used=voice_provider_used,
        audio_path=audio_path,
        audio_url=audio_url,
    )


@router.get('/audio')
def get_generated_ai_reminder_audio(path: str):
    file_path = AUDIO_DIR / path
    if not file_path.exists():
        raise HTTPException(status_code=404, detail='Generated audio file missing')
    return FileResponse(file_path)
