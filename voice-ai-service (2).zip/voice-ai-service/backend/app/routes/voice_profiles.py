from pathlib import Path
import json
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlmodel import Session, select

from ..database import get_session
from ..models import Patient, VoiceProfile
from ..schemas import VoiceProfileView
from ..config import AUDIO_DIR
from ..services.voice_service import voice_service

router = APIRouter(prefix='/voice-profiles', tags=['voice-profiles'])


@router.get('')
def list_voice_profiles(session: Session = Depends(get_session)):
    profiles = session.exec(select(VoiceProfile).order_by(VoiceProfile.created_at.desc())).all()
    return [
        VoiceProfileView(
            id=profile.id,
            patient_id=profile.patient_id,
            profile_name=profile.profile_name,
            speaker_name=profile.speaker_name,
            provider=profile.provider,
            sample_count=profile.sample_count,
            quality_status=profile.quality_status,
            consent_status=profile.consent_status,
            is_ready=profile.is_ready,
            notes=profile.notes,
        )
        for profile in profiles
    ]


@router.post('')
def create_voice_profile(
    patient_id: int = Form(...),
    profile_name: str = Form(...),
    speaker_name: str = Form(...),
    language: str = Form('en'),
    consent_status: str = Form('granted'),
    notes: str = Form(''),
    session: Session = Depends(get_session),
):
    patient = session.get(Patient, patient_id)
    if not patient:
        raise HTTPException(status_code=404, detail='Patient not found')

    profile = VoiceProfile(
        patient_id=patient_id,
        profile_name=profile_name,
        speaker_name=speaker_name,
        language=language,
        consent_status=consent_status,
        notes=notes,
        provider='sample-based',
        quality_status='unchecked',
        is_ready=False,
    )
    session.add(profile)
    session.commit()
    session.refresh(profile)
    return profile


@router.post('/{profile_id}/samples')
def upload_voice_samples(
    profile_id: int,
    files: list[UploadFile] = File(...),
    session: Session = Depends(get_session),
):
    profile = session.get(VoiceProfile, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Voice profile not found')
    if profile.consent_status != 'granted':
        raise HTTPException(status_code=400, detail='Consent must be granted before upload')

    try:
        metadata = voice_service.register_samples(profile_id, files)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    profile.sample_dir = str((Path(metadata['processed_files'][0]).parent if metadata['processed_files'] else Path()).resolve()) if metadata['processed_files'] else None
    profile.sample_count = metadata['sample_count']
    profile.quality_status = metadata['quality_status']
    profile.is_ready = metadata['sample_count'] > 0 and metadata['quality_status'] in {'ready', 'needs_manual_review'}
    profile.notes = (profile.notes + ' ' if profile.notes else '') + 'Samples uploaded and normalized.'
    session.add(profile)
    session.commit()
    session.refresh(profile)
    return {'profile': profile, 'metadata': metadata}




@router.get('/{profile_id}/quality')
def get_voice_profile_quality(profile_id: int, session: Session = Depends(get_session)):
    profile = session.get(VoiceProfile, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Voice profile not found')
    metadata_path = Path(profile.sample_dir).parent / 'metadata.json' if profile.sample_dir else None
    if not metadata_path or not metadata_path.exists():
        return {'profile_id': profile_id, 'quality_status': profile.quality_status, 'quality_reports': []}
    return json.loads(metadata_path.read_text(encoding='utf-8'))

@router.post('/{profile_id}/preview')
def preview_voice(
    profile_id: int,
    text: str = Form(...),
    tone: str = Form('supportive'),
    session: Session = Depends(get_session),
):
    profile = session.get(VoiceProfile, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail='Voice profile not found')

    audio_path, provider_used = voice_service.generate_audio(text=text, voice_profile=profile, tone=tone, language=profile.language)
    if not audio_path:
        raise HTTPException(status_code=500, detail='Could not generate preview')

    return {
        'profile_id': profile.id,
        'provider_used': provider_used,
        'tone': tone,
        'audio_url': f'/voice-profiles/{profile.id}/preview-file?path={Path(audio_path).name}',
        'audio_path': audio_path,
    }


@router.get('/{profile_id}/preview-file')
def get_preview_file(profile_id: int, path: str):
    file_path = AUDIO_DIR / path
    if not file_path.exists():
        raise HTTPException(status_code=404, detail='Preview file missing')
    return FileResponse(file_path)
