from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from ..database import get_session
from ..models import Patient, Medication, ReminderSchedule, MoodStatus
from ..schemas import PatientCreate, MedicationCreate, ScheduleCreate, MoodCreate

router = APIRouter(prefix='/patients', tags=['patients'])


@router.get('')
def list_patients(session: Session = Depends(get_session)):
    return session.exec(select(Patient)).all()


@router.post('')
def create_patient(payload: PatientCreate, session: Session = Depends(get_session)):
    patient = Patient(**payload.model_dump())
    session.add(patient)
    session.commit()
    session.refresh(patient)
    return patient


@router.get('/{patient_id}/medications')
def list_medications(patient_id: int, session: Session = Depends(get_session)):
    return session.exec(select(Medication).where(Medication.patient_id == patient_id)).all()


@router.post('/medications')
def create_medication(payload: MedicationCreate, session: Session = Depends(get_session)):
    med = Medication(**payload.model_dump())
    session.add(med)
    session.commit()
    session.refresh(med)
    return med


@router.post('/schedules')
def create_schedule(payload: ScheduleCreate, session: Session = Depends(get_session)):
    schedule = ReminderSchedule(**payload.model_dump())
    session.add(schedule)
    session.commit()
    session.refresh(schedule)
    return schedule


@router.post('/moods')
def create_mood(payload: MoodCreate, session: Session = Depends(get_session)):
    mood = MoodStatus(**payload.model_dump())
    session.add(mood)
    session.commit()
    session.refresh(mood)
    return mood
