import secrets
from fastapi import APIRouter, Depends, Header, HTTPException
from sqlmodel import Session

from ..database import get_session
from ..config import settings
from ..schemas import EmotionAssessmentPayload, EmotionSyncRequest
from ..services.emotion_integration_service import (
    EmotionIntegrationError,
    effective_emotion,
    fetch_latest_assessment,
    store_assessment,
)


router = APIRouter(prefix='/emotion-integration', tags=['emotion-integration'])


def _response(mood) -> dict:
    return {
        'mood_status_id': mood.id,
        'patient_id': mood.patient_id,
        'source': mood.source,
        'dominant_mood': mood.dominant_mood,
        'primary_emotion': mood.primary_emotion,
        'emotion_confidence': mood.emotion_confidence,
        'effective_emotion': effective_emotion(
            mood.dominant_mood,
            mood.primary_emotion,
            mood.emotion_confidence,
        ),
        'risk_level': mood.risk_level,
        'recorded_at': mood.recorded_at,
    }


@router.post('/patients/{patient_id}/assessments')
def receive_assessment(
    patient_id: int,
    payload: EmotionAssessmentPayload,
    integration_token: str | None = Header(default=None, alias='X-JOG-Integration-Token'),
    session: Session = Depends(get_session),
):
    """Receive the Emotion Detection API assessment payload via push/webhook."""
    if settings.emotion_webhook_token and not (
        integration_token
        and secrets.compare_digest(integration_token, settings.emotion_webhook_token)
    ):
        raise HTTPException(status_code=401, detail='Invalid integration token')
    try:
        mood = store_assessment(session, patient_id, payload, source='emotion_api_push')
    except LookupError:
        raise HTTPException(status_code=404, detail='Patient not found')
    return _response(mood)


@router.post('/patients/{patient_id}/sync')
def sync_latest_assessment(
    patient_id: int,
    payload: EmotionSyncRequest,
    session: Session = Depends(get_session),
):
    """Pull and store the patient's latest assessment from the existing API."""
    try:
        assessment = fetch_latest_assessment(payload.external_patient_id)
        mood = store_assessment(
            session,
            patient_id,
            assessment,
            source='emotion_api_pull',
            external_patient_id=payload.external_patient_id,
        )
    except LookupError:
        raise HTTPException(status_code=404, detail='Patient not found')
    except EmotionIntegrationError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    return _response(mood)
