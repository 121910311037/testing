from datetime import datetime, timedelta
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlmodel import Session, select
from ..database import get_session
from ..models import ReminderEvent, Patient, Medication
from ..schemas import ReminderAction, ReminderView

router = APIRouter(prefix='/reminders', tags=['reminders'])


@router.get('/active')
def active_reminders(session: Session = Depends(get_session)):
    events = session.exec(
        select(ReminderEvent).where(ReminderEvent.status.in_(['delivered', 'snoozed']))
        .order_by(ReminderEvent.reminder_due_at.desc())
    ).all()

    views = []
    for event in events:
        patient = session.get(Patient, event.patient_id)
        medication = session.get(Medication, event.medication_id)
        views.append(
            ReminderView(
                id=event.id,
                patient_name=patient.name if patient else 'Unknown',
                medication_name=medication.name if medication else 'Unknown',
                dose=medication.dose if medication else '',
                due_at=event.reminder_due_at,
                status=event.status,
                reminder_text=event.reminder_text,
                tone_used=event.tone_used,
                audio_url=f'/reminders/{event.id}/audio' if event.audio_path else None,
            )
        )
    return views


@router.post('/{event_id}/action')
def update_reminder_action(event_id: int, payload: ReminderAction, session: Session = Depends(get_session)):
    event = session.get(ReminderEvent, event_id)
    if not event:
        raise HTTPException(status_code=404, detail='Reminder not found')

    action = payload.action.lower()
    if action not in {'taken', 'snoozed', 'missed'}:
        raise HTTPException(status_code=400, detail='Invalid action')

    if action == 'snoozed':
        event.status = 'snoozed'
        event.retry_count += 1
        event.reminder_due_at = datetime.utcnow() + timedelta(minutes=payload.snooze_minutes)
    else:
        event.status = action
        event.responded_at = datetime.utcnow()

    session.add(event)
    session.commit()
    session.refresh(event)
    return event


@router.get('/{event_id}/audio')
def get_audio(event_id: int, session: Session = Depends(get_session)):
    event = session.get(ReminderEvent, event_id)
    if not event or not event.audio_path:
        raise HTTPException(status_code=404, detail='Audio not found')

    path = Path(event.audio_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail='Audio file missing')
    return FileResponse(path)
