from datetime import datetime, time
from typing import Optional
from pydantic import BaseModel


class PatientCreate(BaseModel):
    name: str
    timezone: str = 'America/Chicago'
    preferred_tone: str = 'supportive'
    caregiver_email: Optional[str] = None


class MedicationCreate(BaseModel):
    patient_id: int
    name: str
    dose: str
    instructions: str = ''
    refill_remaining: int = 0


class ScheduleCreate(BaseModel):
    medication_id: int
    reminder_time: time
    frequency: str = 'daily'
    enabled: bool = True
    snooze_minutes: int = 10


class MoodCreate(BaseModel):
    patient_id: int
    source: str = 'questionnaire'
    dominant_mood: str = 'neutral'
    summary: str = ''


class ReminderAction(BaseModel):
    action: str  # taken|snoozed|missed
    snooze_minutes: int = 10


class ReminderView(BaseModel):
    id: int
    patient_name: str
    medication_name: str
    dose: str
    due_at: datetime
    status: str
    reminder_text: str
    tone_used: str
    audio_url: Optional[str]


class VoiceProfileCreate(BaseModel):
    patient_id: int
    profile_name: str
    speaker_name: str
    language: str = 'en'
    consent_status: str = 'granted'
    notes: str = ''


class VoiceProfileView(BaseModel):
    id: int
    patient_id: int
    profile_name: str
    speaker_name: str
    provider: str
    sample_count: int
    quality_status: str
    consent_status: str
    is_ready: bool
    notes: str


class VoicePreviewRequest(BaseModel):
    text: str
    tone: str = 'supportive'
    voice_profile_id: int

class AIReminderRequest(BaseModel):
    patient_name: str = 'John'
    medication_name: str = 'Medication'
    dose: str = ''
    instructions: str = ''
    mood: str = 'neutral'
    voice_profile_id: Optional[int] = None
    preferred_tone: str = 'supportive'
    weekly_taken: int = 0
    weekly_missed: int = 0
    weekly_snoozed: int = 0
    generate_audio: bool = True
    llm_mode: str | None = None  # template | ollama | huggingface


class AIReminderResponse(BaseModel):
    reminder_text: str
    tone: str
    llm_provider_used: str
    voice_profile_id: Optional[int] = None
    voice_provider_used: Optional[str] = None
    audio_path: Optional[str] = None
    audio_url: Optional[str] = None
