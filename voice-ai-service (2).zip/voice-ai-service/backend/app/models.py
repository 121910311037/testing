from __future__ import annotations
from datetime import datetime, time
from typing import Optional
from sqlmodel import SQLModel, Field


class Patient(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    timezone: str = 'America/Chicago'
    preferred_tone: str = 'supportive'
    voice_profile_name: str = 'default'
    caregiver_email: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Medication(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    patient_id: int = Field(index=True, foreign_key='patient.id')
    name: str
    dose: str
    instructions: str = ''
    refill_remaining: int = 0
    active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ReminderSchedule(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    medication_id: int = Field(index=True, foreign_key='medication.id')
    reminder_time: time
    frequency: str = 'daily'
    enabled: bool = True
    snooze_minutes: int = 10
    created_at: datetime = Field(default_factory=datetime.utcnow)


class MoodStatus(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    patient_id: int = Field(index=True, foreign_key='patient.id')
    source: str = 'questionnaire'
    dominant_mood: str = 'neutral'
    summary: str = ''
    recorded_at: datetime = Field(default_factory=datetime.utcnow)


class ReminderEvent(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    patient_id: int = Field(index=True, foreign_key='patient.id')
    medication_id: int = Field(index=True, foreign_key='medication.id')
    schedule_id: int = Field(index=True, foreign_key='reminderschedule.id')
    reminder_due_at: datetime
    status: str = 'pending'  # pending|generated|delivered|taken|snoozed|missed|failed
    tone_used: str = 'supportive'
    reminder_text: str = ''
    audio_path: Optional[str] = None
    voice_profile_id: Optional[int] = Field(default=None, foreign_key='voiceprofile.id')
    voice_provider_used: Optional[str] = None
    generated_at: Optional[datetime] = None
    responded_at: Optional[datetime] = None
    retry_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)


class VoiceProfile(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    patient_id: int = Field(index=True, foreign_key='patient.id')
    profile_name: str = 'default'
    speaker_name: str = 'Loved One'
    provider: str = 'sample-based'  # sample-based | pyttsx3 | gtts
    sample_dir: Optional[str] = None
    sample_count: int = 0
    language: str = 'en'
    consent_status: str = 'pending'  # pending | granted | revoked
    quality_status: str = 'unchecked'  # unchecked | ready | rejected
    notes: str = ''
    is_ready: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
