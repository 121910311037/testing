from __future__ import annotations
from datetime import datetime, timedelta
from sqlmodel import Session, select
from ..models import ReminderSchedule, Medication, Patient, ReminderEvent, VoiceProfile
from .context_service import build_context
from .message_service import generate_message
from .voice_service import voice_service


def due_schedules(session: Session, now: datetime) -> list[tuple[ReminderSchedule, Medication]]:
    schedules = session.exec(select(ReminderSchedule).where(ReminderSchedule.enabled == True)).all()
    results: list[tuple[ReminderSchedule, Medication]] = []

    for schedule in schedules:
        medication = session.get(Medication, schedule.medication_id)
        if not medication or not medication.active:
            continue

        due_at = datetime.combine(now.date(), schedule.reminder_time)
        window_start = due_at
        window_end = due_at + timedelta(minutes=2)

        if window_start <= now <= window_end:
            existing = session.exec(
                select(ReminderEvent)
                .where(ReminderEvent.schedule_id == schedule.id)
                .where(ReminderEvent.reminder_due_at >= due_at)
                .where(ReminderEvent.reminder_due_at < due_at + timedelta(days=1))
            ).first()
            if existing is None:
                results.append((schedule, medication))

    return results


def create_event_for_due_schedule(session: Session, schedule: ReminderSchedule, medication: Medication, now: datetime) -> ReminderEvent:
    patient = session.get(Patient, medication.patient_id)
    context = build_context(session, medication.patient_id, medication.id)
    text, tone = generate_message(context)

    voice_profile = None
    if context.get('voice_profile_id'):
        voice_profile = session.get(VoiceProfile, context['voice_profile_id'])

    audio_path, provider_used = voice_service.generate_audio(
        text=text,
        voice_profile=voice_profile,
        tone=tone,
        language=getattr(voice_profile, 'language', 'en') if voice_profile else 'en',
    )

    event = ReminderEvent(
        patient_id=medication.patient_id,
        medication_id=medication.id,
        schedule_id=schedule.id,
        reminder_due_at=datetime.combine(now.date(), schedule.reminder_time),
        status='delivered',
        tone_used=tone,
        reminder_text=text,
        audio_path=audio_path,
        voice_profile_id=getattr(voice_profile, 'id', None),
        voice_provider_used=provider_used,
        generated_at=datetime.utcnow(),
    )
    session.add(event)
    session.commit()
    session.refresh(event)
    return event
