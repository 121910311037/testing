from __future__ import annotations
import json
import shutil
import subprocess
from pathlib import Path
from typing import Iterable, Optional
import wave
from uuid import uuid4

from ..config import AUDIO_DIR, VOICE_PROFILE_DIR
from .tone_service import normalize_tone


TONE_SETTINGS = {
    'supportive': {'xtts_speed': 0.96, 'xtts_temperature': 0.82, 'rate_multiplier': 0.95},
    'calm': {'xtts_speed': 0.92, 'xtts_temperature': 0.78, 'rate_multiplier': 0.90},
    'cheerful': {'xtts_speed': 1.04, 'xtts_temperature': 0.90, 'rate_multiplier': 1.05},
    'neutral': {'xtts_speed': 1.00, 'xtts_temperature': 0.80, 'rate_multiplier': 1.00},
    'followup_firm': {'xtts_speed': 1.02, 'xtts_temperature': 0.72, 'rate_multiplier': 1.03},
}

ALLOWED_AUDIO_EXTENSIONS = {'.wav', '.mp3', '.m4a', '.mp4', '.ogg', '.flac'}


class VoiceService:
    """
    Productized voice service for the JOG voice team.

    What it supports today:
    - reusable voice profiles backed by uploaded loved-one samples
    - optional XTTS synthesis if Coqui TTS is installed
    - fallback to pyttsx3, then gTTS, then a text sidecar if no TTS engine is available

    The important boundary is stable:
    generate_audio(text, voice_profile) -> audio artifact + provider used
    """

    def create_profile_dir(self, profile_id: int) -> Path:
        profile_dir = VOICE_PROFILE_DIR / f'voice_{profile_id}'
        profile_dir.mkdir(parents=True, exist_ok=True)
        return profile_dir

    def register_samples(self, profile_id: int, uploaded_files: Iterable) -> dict:
        profile_dir = self.create_profile_dir(profile_id)
        raw_dir = profile_dir / 'raw'
        processed_dir = profile_dir / 'processed'
        raw_dir.mkdir(exist_ok=True)
        processed_dir.mkdir(exist_ok=True)

        saved_files: list[str] = []
        processed_files: list[str] = []
        quality_reports: list[dict] = []

        for index, file in enumerate(uploaded_files, start=1):
            suffix = Path(file.filename or '').suffix.lower()
            if suffix not in ALLOWED_AUDIO_EXTENSIONS:
                raise ValueError(f'Unsupported audio type: {suffix or "unknown"}')

            raw_path = raw_dir / f'sample_{index}{suffix}'
            with raw_path.open('wb') as destination:
                shutil.copyfileobj(file.file, destination)
            saved_files.append(raw_path.as_posix())

            processed_path = processed_dir / f'sample_{index}.wav'
            final_path = self._prepare_audio(raw_path, processed_path)
            processed_files.append(final_path.as_posix())
            quality_reports.append(self.analyze_audio_quality(final_path))

        metadata = {
            'profile_id': profile_id,
            'raw_files': saved_files,
            'processed_files': processed_files,
            'sample_count': len(processed_files),
            'quality_reports': quality_reports,
            'quality_status': 'ready' if processed_files and all(q.get('status') == 'ready' for q in quality_reports) else ('needs_manual_review' if processed_files else 'rejected'),
        }
        metadata_path = profile_dir / 'metadata.json'
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        return metadata

    def generate_audio(self, text: str, voice_profile: Optional[object] = None, tone: str = 'supportive', language: str = 'en') -> tuple[str, str]:
        tone = normalize_tone(tone)
        profile_name = getattr(voice_profile, 'profile_name', 'default') if voice_profile else 'default'

        processed_files = self._processed_files_for_profile(voice_profile)
        if processed_files:
            path = self._try_xtts(text=text, speaker_files=processed_files, tone=tone, language=language, profile_name=profile_name)
            if path:
                return path, 'coqui-xtts'

        path = self._try_pyttsx3(text=text, tone=tone, profile_name=profile_name)
        if path:
            return path, 'pyttsx3'

        path = self._try_gtts(text=text, language=language, profile_name=profile_name)
        if path:
            return path, 'gtts'

        path = self._write_text_sidecar(text=text, profile_name=profile_name)
        return path, 'text-fallback'


    def analyze_audio_quality(self, audio_path: Path) -> dict:
        """Lightweight local quality gate for uploaded samples.

        This is intentionally dependency-light so the team can demo today.
        It checks what matters for productization: file exists, duration is
        usable, and the WAV conversion did not produce an empty/broken file.
        """
        result = {
            'path': audio_path.as_posix(),
            'exists': audio_path.exists(),
            'duration_seconds': None,
            'sample_rate': None,
            'channels': None,
            'status': 'rejected',
            'issues': [],
        }
        if not audio_path.exists():
            result['issues'].append('file_missing')
            return result
        if audio_path.suffix.lower() != '.wav':
            result['status'] = 'needs_manual_review'
            result['issues'].append('not_converted_to_wav')
            return result
        try:
            with wave.open(audio_path.as_posix(), 'rb') as wf:
                frames = wf.getnframes()
                rate = wf.getframerate()
                channels = wf.getnchannels()
                duration = frames / float(rate or 1)
                result.update({'duration_seconds': round(duration, 2), 'sample_rate': rate, 'channels': channels})
                if duration < 3:
                    result['issues'].append('too_short_min_3_seconds')
                if duration > 120:
                    result['issues'].append('too_long_max_120_seconds')
                if rate != 16000:
                    result['issues'].append('sample_rate_not_16khz')
                if channels != 1:
                    result['issues'].append('not_mono')
                result['status'] = 'ready' if not result['issues'] else 'needs_manual_review'
        except Exception as exc:
            result['issues'].append(f'wav_read_error:{exc}')
        return result

    def _prepare_audio(self, source: Path, target_wav: Path) -> Path:
        ffmpeg = shutil.which('ffmpeg')
        if ffmpeg:
            command = [
                ffmpeg, '-y', '-i', source.as_posix(), '-vn', '-ac', '1', '-ar', '16000', '-acodec', 'pcm_s16le', target_wav.as_posix()
            ]
            result = subprocess.run(command, capture_output=True)
            if result.returncode == 0 and target_wav.exists():
                return target_wav
        # fallback: keep original file if conversion is unavailable
        return source

    def _processed_files_for_profile(self, voice_profile: Optional[object]) -> list[str]:
        if not voice_profile or not getattr(voice_profile, 'sample_dir', None):
            return []
        sample_dir = Path(voice_profile.sample_dir)
        if not sample_dir.exists():
            return []
        candidates = sorted(sample_dir.glob('*'))
        return [path.as_posix() for path in candidates if path.is_file()]

    def _try_xtts(self, text: str, speaker_files: list[str], tone: str, language: str, profile_name: str) -> Optional[str]:
        try:
            from TTS.api import TTS  # type: ignore
        except Exception:
            return None

        try:
            settings = TONE_SETTINGS[tone]
            filename = f'{profile_name}_{tone}_{uuid4().hex}.wav'
            path = AUDIO_DIR / filename
            tts = TTS('tts_models/multilingual/multi-dataset/xtts_v2', progress_bar=False)
            tts.tts_to_file(
                text=text,
                speaker_wav=speaker_files,
                file_path=path.as_posix(),
                language=language,
                speed=settings['xtts_speed'],
                temperature=settings['xtts_temperature'],
            )
            return path.as_posix() if path.exists() else None
        except Exception:
            return None

    def _try_pyttsx3(self, text: str, tone: str, profile_name: str) -> Optional[str]:
        try:
            import pyttsx3  # type: ignore
        except Exception:
            return None

        try:
            filename = f'{profile_name}_{tone}_{uuid4().hex}.wav'
            path = AUDIO_DIR / filename
            engine = pyttsx3.init()
            base_rate = engine.getProperty('rate')
            rate = int(base_rate * TONE_SETTINGS[tone]['rate_multiplier'])
            engine.setProperty('rate', rate)
            engine.save_to_file(text, path.as_posix())
            engine.runAndWait()
            return path.as_posix() if path.exists() else None
        except Exception:
            return None

    def _try_gtts(self, text: str, language: str, profile_name: str) -> Optional[str]:
        try:
            from gtts import gTTS  # type: ignore
        except Exception:
            return None

        try:
            filename = f'{profile_name}_{uuid4().hex}.mp3'
            path = AUDIO_DIR / filename
            tts = gTTS(text=text, lang=language)
            tts.save(path.as_posix())
            return path.as_posix() if path.exists() else None
        except Exception:
            return None

    def _write_text_sidecar(self, text: str, profile_name: str) -> str:
        path = AUDIO_DIR / f'{profile_name}_{uuid4().hex}.txt'
        path.write_text(text, encoding='utf-8')
        return path.as_posix()


voice_service = VoiceService()
