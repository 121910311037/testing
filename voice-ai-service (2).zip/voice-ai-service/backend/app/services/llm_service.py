from __future__ import annotations

"""LLM reminder text generation for the JOG voice team.

This service restores the dynamic response step from the old notebook into the
current productized codebase. It is deliberately provider-agnostic:

- template: always works, no external dependency
- ollama: free local LLM if the team runs Ollama locally
- huggingface: optional hosted inference using a HF token

The rest of the app calls generate_dynamic_reminder(context) and does not need
to know which provider is being used.
"""

import json
from urllib import request
from typing import Any

from ..config import settings
from .tone_service import mood_to_tone
from .safety_service import validate_reminder_text


TONE_RULES = {
    'supportive': 'warm, caring, emotionally supportive, and brief',
    'calm': 'gentle, slow, reassuring, and brief',
    'followup_firm': 'caring but direct because the reminder has higher adherence importance',
    'cheerful': 'upbeat, encouraging, friendly, and brief',
    'neutral': 'clear, simple, and direct',
}


MOOD_BEHAVIOR_RULES = {
    'sad': 'Be empathetic and comforting without sounding dramatic.',
    'negative': 'Be gentle, supportive, and reassuring.',
    'anxious': 'Be calm and grounding; avoid pressure-heavy wording.',
    'stressed': 'Be calm and simple; reduce cognitive load.',
    'angry': 'Be calm, respectful, and non-confrontational.',
    'irritated': 'Be patient and brief.',
    'happy': 'Be positive and encouraging.',
    'positive': 'Be cheerful and encouraging.',
    'neutral': 'Be clear, warm, and concise.',
}


class LLMResult(dict):
    """Small dict subclass only for clearer typing in editor hints."""


def build_llm_prompt(context: dict[str, Any]) -> str:
    """Build a safe, medication-reminder-specific prompt.

    The LLM should only write the reminder wording. It should not invent medical
    facts or give advice beyond taking the scheduled medication.
    """
    mood = str(context.get('dominant_mood') or 'neutral').lower()
    tone = str(context.get('tone') or 'supportive')
    behavior = MOOD_BEHAVIOR_RULES.get(mood, MOOD_BEHAVIOR_RULES['neutral'])
    tone_rule = TONE_RULES.get(tone, TONE_RULES['supportive'])

    return f"""
You are writing a short voice reminder for a medication-adherence app.

Patient name: {context.get('patient_name', 'Patient')}
Medication: {context.get('medication_name', 'Medication')}
Dose: {context.get('dose', '')}
Instructions: {context.get('instructions', '')}
Mood: {mood}
Tone target: {tone} — {tone_rule}
Recent 7-day adherence: taken={context.get('weekly_taken', 0)}, missed={context.get('weekly_missed', 0)}, snoozed={context.get('weekly_snoozed', 0)}

Behavior rule: {behavior}

Write exactly 1 to 2 short sentences.
Do not diagnose, prescribe, change dosage, mention side effects, or give medical advice.
Do not mention that you are an AI.
End with a simple confirmation request such as "Please confirm once you have taken it" when appropriate.
""".strip()


def generate_template_reminder(context: dict[str, Any]) -> str:
    """Guaranteed fallback reminder text with product-safe wording."""
    patient_name = context.get('patient_name', 'there')
    medication = context.get('medication_name', 'your medicine')
    dose = context.get('dose', '')
    mood = str(context.get('dominant_mood') or 'neutral').lower()
    tone = str(context.get('tone') or 'supportive')

    med_phrase = f"{medication} {dose}".strip()
    if tone == 'cheerful':
        lead = f"Hi {patient_name}, it’s time for {med_phrase}—you’ve got this."
    elif tone == 'calm':
        lead = f"Hi {patient_name}, take a moment and please take your {med_phrase}."
    elif tone == 'followup_firm':
        lead = f"{patient_name}, this is an important follow-up reminder to take your {med_phrase}."
    elif tone == 'neutral':
        lead = f"Reminder: it is time to take your {med_phrase}."
    else:
        lead = f"Hi {patient_name}, this is your reminder to take your {med_phrase}."

    if mood in {'sad', 'negative', 'anxious', 'stressed'}:
        tail = 'Please confirm once you have taken it, or snooze if you need a few minutes.'
    elif context.get('weekly_missed', 0) >= 2:
        tail = 'Please confirm once it is taken so your care team knows you are on track.'
    else:
        tail = 'Please confirm once you have taken it.'
    return f'{lead} {tail}'


def _call_ollama(prompt: str) -> str:
    payload = json.dumps({'model': settings.ollama_model, 'prompt': prompt, 'stream': False}).encode('utf-8')
    req = request.Request(
        settings.ollama_url.rstrip('/') + '/api/generate',
        data=payload,
        headers={'Content-Type': 'application/json'},
    )
    with request.urlopen(req, timeout=settings.llm_timeout_seconds) as resp:
        data = json.loads(resp.read().decode('utf-8'))
    return str(data.get('response', '')).strip()


def _call_huggingface(prompt: str) -> str:
    """Call Hugging Face InferenceClient if configured.

    Requires: pip install huggingface_hub and env var JOG_HF_API_TOKEN.
    If either is missing, the caller catches the error and falls back safely.
    """
    if not settings.hf_api_token:
        raise RuntimeError('JOG_HF_API_TOKEN is not set')

    from huggingface_hub import InferenceClient  # type: ignore

    client = InferenceClient(token=settings.hf_api_token)

    # Chat-capable models are preferred. The model is configurable so the team
    # can use Mistral, Llama, or another free/available HF model.
    response = client.chat_completion(
        model=settings.hf_model,
        messages=[
            {'role': 'system', 'content': 'You write safe, short medication reminders only.'},
            {'role': 'user', 'content': prompt},
        ],
        max_tokens=settings.llm_max_tokens,
        temperature=settings.llm_temperature,
    )
    return response.choices[0].message.content.strip()


def _sanitize_response(text: str) -> str:
    cleaned = ' '.join((text or '').replace('\n', ' ').split()).strip(' "')
    if not cleaned:
        return ''
    # Keep it short enough for a voice reminder; avoid long LLM rambling.
    words = cleaned.split()
    if len(words) > 55:
        cleaned = ' '.join(words[:55]).rstrip(',.') + '.'
    return cleaned


def generate_dynamic_reminder(context: dict[str, Any], llm_mode: str | None = None) -> LLMResult:
    """Return generated reminder text + tone + provider used.

    This is the single integration function for the rest of the product.
    """
    tone = mood_to_tone(
        mood=context.get('dominant_mood', 'neutral'),
        missed_count=int(context.get('weekly_missed', 0) or 0),
        preferred_tone=context.get('preferred_tone', 'supportive'),
    )
    context = {**context, 'tone': tone}
    prompt = build_llm_prompt(context)

    requested_mode = (llm_mode or settings.llm_mode or 'template').strip().lower()
    if requested_mode not in {'template', 'ollama', 'huggingface'}:
        requested_mode = 'template'

    provider = 'template'
    text = ''

    if requested_mode == 'ollama':
        try:
            text = _sanitize_response(_call_ollama(prompt))
            provider = 'ollama'
        except Exception as exc:
            text = ''
            provider = f'template-fallback:ollama_error:{type(exc).__name__}'
    elif requested_mode == 'huggingface':
        try:
            text = _sanitize_response(_call_huggingface(prompt))
            provider = 'huggingface'
        except Exception as exc:
            text = ''
            provider = f'template-fallback:hf_error:{type(exc).__name__}'

    if text:
        safety = validate_reminder_text(text)
        if safety.passed:
            text = safety.text
        else:
            provider = f'template-fallback:safety:{safety.reason}'
            text = ''

    if not text:
        text = generate_template_reminder(context)
        if provider == 'template':
            provider = 'template'

    return LLMResult({
        'text': text,
        'tone': tone,
        'llm_provider_used': provider,
        'prompt': prompt if settings.debug_return_prompts else None,
    })
