from __future__ import annotations

PRODUCT_TONES = ['supportive', 'calm', 'cheerful', 'neutral', 'followup_firm']

MOOD_TO_TONE = {
    'positive': 'cheerful',
    'happy': 'cheerful',
    'neutral': 'supportive',
    'okay': 'supportive',
    'sad': 'calm',
    'negative': 'calm',
    'anxious': 'calm',
    'stressed': 'calm',
    'angry': 'followup_firm',
    'irritated': 'followup_firm',
    'missed': 'followup_firm',
}


def normalize_tone(tone: str | None) -> str:
    if not tone:
        return 'supportive'
    cleaned = tone.strip().lower().replace(' ', '_')
    return cleaned if cleaned in PRODUCT_TONES else MOOD_TO_TONE.get(cleaned, 'supportive')


def mood_to_tone(mood: str | None, missed_count: int = 0, preferred_tone: str | None = None) -> str:
    """Map external mood-team output to product voice-delivery tone.

    This lets the voice team continue independently using mocked moods now,
    and later swap the input to the mood team's real API response.
    """
    if missed_count >= 2:
        return 'followup_firm'
    if mood:
        return normalize_tone(MOOD_TO_TONE.get(mood.strip().lower(), mood))
    return normalize_tone(preferred_tone)
