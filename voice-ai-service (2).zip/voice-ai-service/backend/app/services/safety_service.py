from __future__ import annotations

"""Safety guardrails for generated medication reminder text.

This is not a full clinical safety system. It is a lightweight application-level
filter that keeps reminder wording inside the product's intended scope:
remind, encourage, confirm. It should be expanded before production release.
"""

from dataclasses import dataclass
import re


BLOCKED_PATTERNS = [
    r"\b(change|increase|decrease|double|skip|stop)\b.{0,30}\b(dose|dosage|medication|medicine|pill)\b",
    r"\bdiagnos(e|is|ing)\b",
    r"\bside effects?\b",
    r"\bcontraindication\b",
    r"\bmedical advice\b",
    r"\bprescrib(e|ed|ing)\b",
    r"\bemergency\b(?!\s+services)",
]

@dataclass
class SafetyResult:
    text: str
    passed: bool
    reason: str = "ok"


def sanitize_reminder_text(text: str, max_words: int = 45) -> str:
    cleaned = " ".join((text or "").replace("\n", " ").split()).strip(' "')
    if not cleaned:
        return ""

    # Remove common model preambles.
    cleaned = re.sub(r"^(Reminder:|Response:|Here is.*?:)\s*", "", cleaned, flags=re.I)

    words = cleaned.split()
    if len(words) > max_words:
        cleaned = " ".join(words[:max_words]).rstrip(",;:") + "."

    return cleaned


def validate_reminder_text(text: str) -> SafetyResult:
    cleaned = sanitize_reminder_text(text)
    if not cleaned:
        return SafetyResult(text="", passed=False, reason="empty_response")

    lower = cleaned.lower()
    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, lower):
            return SafetyResult(text=cleaned, passed=False, reason=f"blocked_pattern:{pattern}")

    return SafetyResult(text=cleaned, passed=True)
