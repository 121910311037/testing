from __future__ import annotations

import json
from typing import Any
from urllib import error, parse, request

from sqlmodel import Session

from ..config import settings
from ..models import MoodStatus, Patient
from ..schemas import EmotionAssessmentPayload
from ..time_utils import utc_now


EMOTION_TO_CONTEXT = {
    'joy': 'positive',
    'love': 'positive',
    'sadness': 'sad',
    'fear': 'anxious',
    'anger': 'angry',
    'surprise': 'neutral',
    'disgust': 'negative',
}


class EmotionIntegrationError(RuntimeError):
    """Raised when the external mood service cannot provide a valid payload."""


def effective_emotion(
    dominant_mood: str | None,
    primary_emotion: str | None,
    confidence: float | None,
) -> str:
    """Prefer a confident text emotion; otherwise use questionnaire mood."""
    mood = (dominant_mood or 'neutral').strip().lower()
    emotion = (primary_emotion or '').strip().lower()
    if emotion and confidence is not None and confidence >= settings.emotion_min_confidence:
        return EMOTION_TO_CONTEXT.get(emotion, emotion)
    return mood


def fetch_latest_assessment(external_patient_id: str) -> EmotionAssessmentPayload:
    patient_segment = parse.quote(external_patient_id.strip(), safe='')
    url = (
        settings.emotion_api_base_url.rstrip('/')
        + f'/api/history/{patient_segment}/latest'
    )
    req = request.Request(url, headers={'Accept': 'application/json'})
    try:
        with request.urlopen(req, timeout=settings.emotion_api_timeout_seconds) as response:
            payload: Any = json.loads(response.read().decode('utf-8'))
    except error.HTTPError as exc:
        raise EmotionIntegrationError(f'emotion_api_http_{exc.code}') from exc
    except (error.URLError, TimeoutError) as exc:
        raise EmotionIntegrationError('emotion_api_unavailable') from exc
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise EmotionIntegrationError('emotion_api_invalid_json') from exc

    try:
        return EmotionAssessmentPayload.model_validate(payload)
    except ValueError as exc:
        raise EmotionIntegrationError('emotion_api_invalid_payload') from exc


def store_assessment(
    session: Session,
    patient_id: int,
    assessment: EmotionAssessmentPayload,
    source: str,
    external_patient_id: str | None = None,
) -> MoodStatus:
    if session.get(Patient, patient_id) is None:
        raise LookupError('patient_not_found')

    mood = MoodStatus(
        patient_id=patient_id,
        source=source,
        dominant_mood=assessment.dominant_mood.strip().lower(),
        primary_emotion=(assessment.primary_emotion or '').strip().lower() or None,
        emotion_confidence=assessment.emotion_confidence,
        risk_level=assessment.risk_level,
        mood_scores_json=json.dumps(assessment.mood_scores, sort_keys=True),
        external_patient_id=external_patient_id or assessment.patient_id,
        assessment_timestamp=assessment.timestamp,
        summary=_assessment_summary(assessment),
        recorded_at=utc_now(),
    )
    session.add(mood)
    session.commit()
    session.refresh(mood)
    return mood


def _assessment_summary(assessment: EmotionAssessmentPayload) -> str:
    parts = [f'mood={assessment.dominant_mood}']
    if assessment.primary_emotion:
        confidence = (
            f'{assessment.emotion_confidence:.2f}'
            if assessment.emotion_confidence is not None
            else 'unknown'
        )
        parts.append(f'emotion={assessment.primary_emotion} ({confidence})')
    if assessment.risk_level:
        parts.append(f'risk={assessment.risk_level}')
    return '; '.join(parts)
