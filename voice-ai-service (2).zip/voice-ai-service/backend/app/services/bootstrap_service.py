from datetime import datetime, timedelta
from sqlmodel import Session, select
from ..models import Patient, Medication, ReminderSchedule, MoodStatus, VoiceProfile


def seed_demo(session: Session) -> None:
    existing = session.exec(select(Patient)).first()
    if existing:
        return

    patient = Patient(name='John Doe', preferred_tone='supportive', caregiver_email='caregiver@example.com')
    session.add(patient)
    session.commit()
    session.refresh(patient)

    voice = VoiceProfile(
        patient_id=patient.id,
        profile_name='john_family_voice',
        speaker_name='John Family Voice',
        provider='sample-based',
        consent_status='granted',
        quality_status='unchecked',
        is_ready=False,
        notes='Upload loved-one audio samples to make this profile ready for XTTS sample-based synthesis.',
    )
    session.add(voice)

    medication = Medication(
        patient_id=patient.id,
        name='Lisinopril',
        dose='10 mg',
        instructions='Take with water after breakfast',
        refill_remaining=8,
    )
    session.add(medication)
    session.commit()
    session.refresh(medication)

    due_time = (datetime.now() + timedelta(minutes=1)).time().replace(second=0, microsecond=0)
    schedule = ReminderSchedule(medication_id=medication.id, reminder_time=due_time, frequency='daily')
    session.add(schedule)

    mood = MoodStatus(patient_id=patient.id, dominant_mood='neutral', summary='Patient seems okay today.')
    session.add(mood)
    session.commit()
