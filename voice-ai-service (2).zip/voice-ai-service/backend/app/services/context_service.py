from datetime import datetime, timedelta
from sqlmodel import Session, select
from ..models import Patient, Medication, MoodStatus, ReminderEvent, VoiceProfile


def build_context(session: Session, patient_id: int, medication_id: int) -> dict:
    patient = session.get(Patient, patient_id)
    medication = session.get(Medication, medication_id)

    latest_mood = session.exec(
        select(MoodStatus)
        .where(MoodStatus.patient_id == patient_id)
        .order_by(MoodStatus.recorded_at.desc())
    ).first()

    recent_events = session.exec(
        select(ReminderEvent)
        .where(ReminderEvent.patient_id == patient_id)
        .where(ReminderEvent.created_at >= datetime.utcnow() - timedelta(days=7))
    ).all()

    active_voice = session.exec(
        select(VoiceProfile)
        .where(VoiceProfile.patient_id == patient_id)
        .where(VoiceProfile.is_ready == True)
        .order_by(VoiceProfile.created_at.desc())
    ).first()

    taken = sum(1 for event in recent_events if event.status == 'taken')
    missed = sum(1 for event in recent_events if event.status == 'missed')
    snoozed = sum(1 for event in recent_events if event.status == 'snoozed')

    return {
        'patient_name': patient.name if patient else 'Patient',
        'preferred_tone': patient.preferred_tone if patient else 'supportive',
        'caregiver_email': patient.caregiver_email if patient else None,
        'medication_name': medication.name if medication else 'Medication',
        'dose': medication.dose if medication else '',
        'instructions': medication.instructions if medication else '',
        'refill_remaining': medication.refill_remaining if medication else 0,
        'dominant_mood': latest_mood.dominant_mood if latest_mood else 'neutral',
        'mood_summary': latest_mood.summary if latest_mood else '',
        'weekly_taken': taken,
        'weekly_missed': missed,
        'weekly_snoozed': snoozed,
        'voice_profile_id': active_voice.id if active_voice else None,
    }
