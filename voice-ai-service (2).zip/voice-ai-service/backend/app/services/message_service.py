"""Backward-compatible wrapper for reminder message generation.

The old code called generate_message(context). The new implementation delegates
to llm_service so scheduled reminders and preview reminders use the same dynamic
LLM/template logic.
"""

from .llm_service import generate_dynamic_reminder, build_llm_prompt, generate_template_reminder


def generate_message(context: dict) -> tuple[str, str]:
    result = generate_dynamic_reminder(context)
    return result['text'], result['tone']
