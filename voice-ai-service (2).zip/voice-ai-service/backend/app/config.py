from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / 'data'
AUDIO_DIR = DATA_DIR / 'audio'
VOICE_PROFILE_DIR = DATA_DIR / 'voice_profiles'
DATA_DIR.mkdir(parents=True, exist_ok=True)
AUDIO_DIR.mkdir(parents=True, exist_ok=True)
VOICE_PROFILE_DIR.mkdir(parents=True, exist_ok=True)


class Settings(BaseSettings):
    app_name: str = 'JOG Voice AI Service'
    database_url: str = f"sqlite:///{(DATA_DIR / 'jog.db').as_posix()}"
    llm_mode: str = 'ollama'  # template | ollama | huggingface
    ollama_model: str = 'llama3.1:8b'
    ollama_url: str = 'http://localhost:11434'
    hf_model: str = 'meta-llama/Llama-3.1-8B-Instruct'
    hf_api_token: str | None = None
    llm_timeout_seconds: int = 20
    llm_max_tokens: int = 80
    llm_temperature: float = 0.55
    debug_return_prompts: bool = False
    allowed_origins: str = 'http://localhost:8501,http://127.0.0.1:8501'
    reminder_poll_seconds: int = 20
    timezone: str = 'America/Chicago'
    host_base_url: str = 'http://localhost:8000'

    model_config = SettingsConfigDict(env_prefix='JOG_', extra='ignore')


settings = Settings()
