"""Simple API smoke test for meeting/demo.
Run while backend is active:
    python scripts/smoke_test_api.py
"""
import requests

BASE = 'http://localhost:8000'


def main() -> None:
    print('Root:', requests.get(BASE + '/', timeout=10).json())
    patients = requests.get(BASE + '/patients', timeout=10).json()
    print('Patients:', patients[:2])
    profiles = requests.get(BASE + '/voice-profiles', timeout=10).json()
    print('Voice profiles:', profiles[:2])
    reminders = requests.get(BASE + '/reminders/active', timeout=10).json()
    print('Active reminders:', reminders[:2])

    ai_payload = {
        'patient_name': 'John',
        'medication_name': 'Metformin',
        'dose': '500 mg',
        'instructions': 'Take after food',
        'mood': 'sad',
        'preferred_tone': 'supportive',
        'weekly_taken': 3,
        'weekly_missed': 0,
        'weekly_snoozed': 0,
        'generate_audio': True,
    }
    ai_resp = requests.post(BASE + '/ai-reminders/generate', json=ai_payload, timeout=60)
    print('AI reminder:', ai_resp.status_code, ai_resp.text[:500])
    ai_resp.raise_for_status()


if __name__ == '__main__':
    main()
