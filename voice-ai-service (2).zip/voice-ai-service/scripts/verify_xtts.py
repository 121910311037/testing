"""Run a real XTTS-v2 inference check with a consented reference WAV.

This script is intentionally separate from automated tests because it downloads
large model weights and requires a real voice sample whose use is authorized.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from types import SimpleNamespace

from backend.app.config import AUDIO_DIR
from backend.app.services.voice_service import VoiceService


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--sample', required=True, type=Path)
    parser.add_argument('--text', default='This is a JOG XTTS voice cloning validation reminder.')
    parser.add_argument('--language', default='en')
    parser.add_argument('--tone', default='supportive')
    args = parser.parse_args()

    sample = args.sample.resolve()
    if not sample.is_file() or sample.suffix.lower() != '.wav':
        raise SystemExit('--sample must point to an existing WAV file')

    service = VoiceService(audio_dir=AUDIO_DIR, voice_profile_dir=sample.parent)
    profile = SimpleNamespace(
        profile_name='xtts_validation',
        sample_dir=sample.parent.as_posix(),
        consent_status='granted',
        is_ready=True,
    )
    result = service.generate_audio_result(
        text=args.text,
        voice_profile=profile,
        tone=args.tone,
        language=args.language,
        require_cloned_voice=True,
    )
    print(f'provider={result.provider}')
    print(f'cloned_voice_used={result.is_cloned}')
    print(f'output={result.path}')


if __name__ == '__main__':
    main()
