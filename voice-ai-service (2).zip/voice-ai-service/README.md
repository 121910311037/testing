# JOG Voice AI Service

FastAPI + Streamlit development codebase for the JOG app voice AI module.

## What this project does

Current flow:

```text
patient context + medication + mood
→ Llama/template reminder text
→ mood-to-tone mapping
→ selected voice profile / fallback voice
→ audio output
```

The current codebase is the active source of truth. Old notebook experiments are not required.

## Main components

- `backend/app/services/llm_service.py` — dynamic reminder generation using Ollama Llama 3.1, Hugging Face, or template fallback.
- `backend/app/services/safety_service.py` — basic generated-text safety checks.
- `backend/app/services/tone_service.py` — mood-to-tone mapping and product tone controls.
- `backend/app/services/voice_service.py` — voice profile handling and audio generation/fallback.
- `backend/app/routes/ai_reminders.py` — end-to-end AI reminder API.
- `frontend/app.py` — Streamlit demo/testing UI.

## Run on Windows

```powershell
cd path\to\jog_voice_team_consolidated
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
pytest -q
uvicorn backend.app.main:app --reload
```

In a second terminal:

```powershell
cd path\to\jog_voice_team_consolidated
.venv\Scripts\activate
streamlit run frontend/app.py
```

Open: `http://localhost:8501`

## Run local Llama 3.1 with Ollama

Install Ollama, then:

```bash
ollama pull llama3.1:8b
ollama serve
```

Set `.env` or environment variables:

```text
JOG_LLM_MODE=ollama
JOG_OLLAMA_MODEL=llama3.1:8b
```

In Streamlit, choose `ollama` as the LLM provider.

## GitHub notes

Do not commit:
- `.venv`
- `.env`
- generated audio files
- local DB files
- real patient data
- real loved-one voice samples

See `docs/CURRENT_STATUS_AND_TODO.md` for completion status and remaining work.
