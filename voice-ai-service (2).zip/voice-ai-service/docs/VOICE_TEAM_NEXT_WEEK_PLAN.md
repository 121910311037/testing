# JOG Voice Team — Next Week Implementation Plan

## Goal
Turn last week's MVP into an integration-ready voice service that other teams can call without depending on the notebook.

## What we are building now
1. Reusable loved-one voice profiles.
2. Audio sample intake and normalization.
3. Lightweight quality gate for uploaded samples.
4. Product tone system: supportive, calm, cheerful, neutral, followup_firm.
5. Mood-to-tone mapper so the mood team can plug in later.
6. Voice generation endpoint using `voice_profile_id`.
7. Fallback path when XTTS / local TTS fails.
8. Demo UI and API smoke script.

## Our implementation order
### Step 1 — Voice profile foundation
- Create profile metadata.
- Store patient, speaker name, language, consent status, sample directory, sample count, quality status.
- Output: stable `voice_profile_id`.

### Step 2 — Sample intake and preprocessing
- Accept wav/mp3/m4a/mp4/ogg/flac.
- Convert to mono 16 kHz WAV using ffmpeg when available.
- Save raw and processed samples separately.
- Output: normalized sample paths for cloning.

### Step 3 — Quality gate
- Validate file exists.
- Check WAV duration, sample rate, channel count.
- Mark profile as `ready`, `needs_manual_review`, or `rejected`.
- Output: quality report endpoint.

### Step 4 — Voice synthesis by profile
- Input: text, tone, voice_profile_id.
- Retrieve saved samples from voice profile.
- Try XTTS first if available.
- Fall back to pyttsx3, then gTTS, then text sidecar.
- Output: audio URL + provider used.

### Step 5 — Integration readiness
- Mood team output is not required yet.
- Until mood API is ready, use mocked mood strings and the local mood-to-tone mapper.
- Once mood team has an API, replace mock mood input with their real `dominant_mood` field.

## Dependencies
### We depend on mood team for later
- `dominant_mood`
- optional confidence
- optional mood summary

If this is not ready, we continue with mock values.

### We depend on UI team later
- Upload screen for loved-one samples.
- Preview screen for generated audio.
- Reminder playback screen.

If this is not ready, we use Streamlit/demo API.

### We depend on backend later
- Reminder schedule event.
- Medication context.
- Patient profile and selected voice profile.

If this is not ready, we use seeded demo data and direct API calls.

## Demo flow
1. Create patient.
2. Create voice profile for loved one.
3. Upload audio samples.
4. Generate previews for supportive, calm, cheerful, followup_firm.
5. Show active reminder using voice profile.
6. Confirm/snooze/miss the reminder.
