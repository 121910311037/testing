# LLM Dynamic Response Integration

This version restores the dynamic reminder step from the original Dynamic Voice Cloning notebook into the current productized codebase.

## New flow

```text
patient context + mood + medication
        ↓
LLM/template reminder generator
        ↓
mood-to-tone mapper
        ↓
voice_profile_id / selected loved-one voice
        ↓
voice generation + fallback audio
```

## Main additions

- `backend/app/services/llm_service.py` — provider-agnostic dynamic reminder generation.
- `backend/app/routes/ai_reminders.py` — API endpoint for generating text + audio in one request.
- `POST /ai-reminders/generate` — meeting-demo endpoint for the full AI voice flow.
- Streamlit `AI Reminder Demo` tab — quick demo UI for mood/context → reminder text → audio.

## Supported LLM modes

Configured using environment variable `JOG_LLM_MODE`.

### 1. Template mode, default
Always works, no external dependency.

```bash
export JOG_LLM_MODE=template
```

### 2. Ollama mode, local free LLM
Requires Ollama running locally.

```bash
export JOG_LLM_MODE=ollama
export JOG_OLLAMA_MODEL=llama3.1:8b
uvicorn backend.app.main:app --reload
```

### 3. Hugging Face mode
Optional hosted inference. Requires a Hugging Face token.

```bash
export JOG_LLM_MODE=huggingface
export JOG_HF_API_TOKEN=your_token_here
export JOG_HF_MODEL=mistralai/Mistral-7B-Instruct-v0.3
uvicorn backend.app.main:app --reload
```

If Ollama or Hugging Face fails, the app falls back to a safe template reminder automatically.

## API example

```bash
curl -X POST http://127.0.0.1:8000/ai-reminders/generate \
  -H "Content-Type: application/json" \
  -d '{
    "patient_name": "John",
    "medication_name": "Metformin",
    "dose": "500 mg",
    "instructions": "Take after food",
    "mood": "sad",
    "preferred_tone": "supportive",
    "weekly_taken": 3,
    "weekly_missed": 0,
    "weekly_snoozed": 0,
    "generate_audio": true
  }'
```

Expected output contains:

- `reminder_text`
- `tone`
- `llm_provider_used`
- `voice_provider_used`
- `audio_url`

## Why this structure

The LLM is separated from the voice service because reminder wording and voice rendering are two different responsibilities:

- LLM service creates safe, short reminder text.
- Tone service converts mood/adherence context into product-friendly voice tones.
- Voice service renders the approved text using a selected voice profile or fallback voice.

This makes the app easy to integrate later with the mood-questionnaire team and backend scheduler.
