# Test Results and Runbook

## What was tested before handoff

Environment note: the sandbox did not already have project dependencies installed, so I installed the backend-core dependencies only for runtime checks. Full frontend dependencies such as Streamlit may need to be installed on your machine with `pip install -r requirements.txt`.

### Passed checks

1. Python syntax/import compile check

```bash
python -m compileall backend frontend scripts tests
```

Result: passed. All project Python files compiled successfully.

2. Unit tests

```bash
python -m pytest -q
```

Result: passed. Tone mapper tests passed.

3. Backend startup

```bash
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8125
```

Result: passed. Backend started successfully and returned HTTP 200 from `/`.

4. Voice profile listing

```bash
curl http://127.0.0.1:8125/voice-profiles
```

Result: passed. Returned seeded voice profile data.

5. Voice profile creation

Created a new profile using `POST /voice-profiles`.

Result: passed. Returned a new profile with `sample_count: 0`, `quality_status: unchecked`, and `is_ready: false`.

6. Voice sample upload and quality report

Uploaded a generated 16 kHz mono WAV test sample using `POST /voice-profiles/{profile_id}/samples`.

Result: passed. The file was accepted, stored under the profile folder, and quality report returned. The synthetic sample was flagged `needs_manual_review` because the created test file was shorter than the minimum 3 seconds expected by the quality gate.

7. Preview generation fallback

Called `POST /voice-profiles/{profile_id}/preview` with text and tone.

Result: passed. In the sandbox, Coqui XTTS / pyttsx3 / gTTS were not available, so the service correctly used the `text-fallback` provider and returned an output artifact path.

## What still needs to be tested on your machine

1. Full Streamlit UI startup

```bash
streamlit run frontend/app.py
```

2. Real audio playback in browser.

3. Coqui XTTS sample-based cloning path. This requires installing Coqui TTS and having enough runtime resources. If Coqui is installed, the system first tries XTTS using the uploaded loved-one samples before falling back.

4. Real loved-one voice sample quality. Use clean recordings, ideally 10–30 seconds total minimum, little background noise, and one speaker only.

## Recommended run order

```bash
cd jog_voice_team_consolidated
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m pytest -q
uvicorn backend.app.main:app --reload
```

In another terminal:

```bash
cd jog_voice_team_consolidated
source .venv/bin/activate   # Windows: .venv\Scripts\activate
streamlit run frontend/app.py
```

## Demo scenario

1. Open backend docs at `http://localhost:8000/docs`.
2. Open the Streamlit app.
3. Create/select a patient.
4. Create a voice profile.
5. Upload loved-one samples.
6. Open quality report.
7. Generate previews with `calm`, `supportive`, `cheerful`, and `followup_firm`.
8. Explain that mood-team output will later plug into `tone_service.py`.


## Latest LLM integration checks

Completed local checks after adding the LLM dynamic reminder layer:

- Python compile check: passed.
- Unit tests: passed (`3 passed`).
- Backend startup: passed after installing requirements.
- Root endpoint `/`: passed.
- `POST /ai-reminders/generate` with `generate_audio=false`: passed.
- `POST /ai-reminders/generate` with `generate_audio=true`: passed using fallback voice provider in this environment.

Example observed response:

```json
{
  "reminder_text": "Hi John, it’s time for Metformin 500 mg—you’ve got this. Please confirm once you have taken it.",
  "tone": "cheerful",
  "llm_provider_used": "template",
  "voice_provider_used": "pyttsx3",
  "audio_url": "/ai-reminders/audio?path=...wav"
}
```

Not fully verified here:

- Real Hugging Face/Mistral response generation, because it requires `JOG_HF_API_TOKEN`.
- Real XTTS cloned loved-one voice output, because it requires the full Coqui TTS runtime/model installed.
- Streamlit browser interaction, though the code compiles and the backend API is available.
