# Voice Team API Contracts

## Create voice profile
`POST /voice-profiles`

Form fields:
- `patient_id`: integer
- `profile_name`: string, e.g. `mom_voice`
- `speaker_name`: string, e.g. `Mom`
- `language`: string, default `en`
- `consent_status`: `granted | pending | revoked`
- `notes`: string

Output includes:
- `id`: voice_profile_id
- `sample_count`
- `quality_status`
- `is_ready`

## Upload samples
`POST /voice-profiles/{profile_id}/samples`

Multipart:
- `files`: one or more audio files

Output:
- profile metadata
- raw files
- processed files
- quality reports

## Get quality report
`GET /voice-profiles/{profile_id}/quality`

Output:
- sample count
- processed files
- per-sample quality status
- quality issues if any

## Generate preview/audio
`POST /voice-profiles/{profile_id}/preview`

Form fields:
- `text`: reminder text
- `tone`: `supportive | calm | cheerful | neutral | followup_firm`

Output:
- `provider_used`: `coqui-xtts | pyttsx3 | gtts | text-fallback`
- `audio_url`
- `audio_path`

## Future mood-team contract
Expected mood payload:
```json
{
  "patient_id": 1,
  "dominant_mood": "anxious",
  "confidence": 0.82,
  "summary": "Patient reported stress and poor sleep."
}
```

Voice team maps `dominant_mood` to product tone internally.


## AI dynamic reminder endpoint

### POST `/ai-reminders/generate`

Restores the full AI voice flow from the previous notebook in product/API form.

Input:

```json
{
  "patient_name": "John",
  "medication_name": "Metformin",
  "dose": "500 mg",
  "instructions": "Take after food",
  "mood": "sad",
  "preferred_tone": "supportive",
  "weekly_taken": 3,
  "weekly_missed": 0,
  "weekly_snoozed": 0,
  "voice_profile_id": 1,
  "generate_audio": true
}
```

Output:

```json
{
  "reminder_text": "Hi John, take a moment and please take your Metformin 500 mg. Please confirm once you have taken it, or snooze if you need a few minutes.",
  "tone": "calm",
  "llm_provider_used": "template",
  "voice_profile_id": 1,
  "voice_provider_used": "pyttsx3",
  "audio_path": "data/audio/...wav",
  "audio_url": "/ai-reminders/audio?path=...wav"
}
```

Notes:

- `mood` can come from the mood-questionnaire team later.
- `voice_profile_id` selects the loved-one voice profile.
- If no real LLM is configured, the service uses safe template fallback.
- If cloning is unavailable, the voice service falls back to local/default TTS or text sidecar.
