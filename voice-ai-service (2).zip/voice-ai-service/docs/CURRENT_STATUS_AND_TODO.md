# JOG Voice AI Service — Current Status and Remaining Work

## Current source of truth
The current VS Code/FastAPI project is the source of truth. The previous notebook work is treated as discarded/reference only and is not mixed into this codebase.

## Completed in this codebase
- API-first FastAPI backend
- Streamlit development/demo UI
- Reusable voice profile concept with `voice_profile_id`
- Voice sample upload and existing basic preparation path
- Dynamic reminder generation service with request-level provider selection
- Local Llama path through Ollama (`llama3.1:8b`)
- Hosted Hugging Face provider hook for later use
- Template fallback for stable demos
- Mood-to-tone mapping service
- Tone-aware voice generation interface
- Basic generated-text safety guardrails
- Fallback TTS path when cloned voice runtime is unavailable
- Tests for tone, LLM/template behavior, and safety filtering
- GitHub-safe `.gitignore` and `.env.example`

## Intentionally still pending from our side
- Real voice preprocessing improvements: silence trimming, noise checks, clipping checks, quality scoring improvements, and rejection rules
- Real XTTS cloned voice validation in target runtime
- Stronger acoustic modulation for tones using the actual voice cloning provider
- Consent enforcement beyond storing consent metadata
- Production database migration from SQLite to Postgres or managed DB
- Authentication/authorization
- PHI-safe logging and audit trail
- Docker and CI/CD
- Async job queue for long audio generation tasks

## Waiting on other teams
- Mood questionnaire team: final API/output contract for patient mood and confidence
- Backend/app team: production reminder scheduler contract
- Mobile app team: API integration and playback behavior
- Product team: caregiver escalation rules and confirmation flow requirements
- Alexa team/product decision: account linking, reminder permission flow, and whether Alexa should play generated audio or use Alexa's native voice

## Components we can now mark as started/completed for MVP
- LLM reminder generation layer: MVP complete with Ollama/template/provider abstraction
- Safety guardrail layer: basic MVP complete
- GitHub readiness baseline: complete for development branch
- API-first structure: complete for MVP

## Current estimate
Voice AI module: approximately 65% complete for MVP integration.
Production readiness: approximately 40% complete.
Alexa readiness: approximately 30% complete.
