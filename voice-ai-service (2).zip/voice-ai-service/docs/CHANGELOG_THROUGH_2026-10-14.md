# Exact Changed Files — 2026-08-17 through 2026-10-14

All paths are relative to `voice-ai-service`. No other repository component was
modified.

## Modified

- `.env.example`
- `README.md`
- `backend/app/config.py`
- `backend/app/database.py`
- `backend/app/main.py`
- `backend/app/models.py`
- `backend/app/routes/ai_reminders.py`
- `backend/app/routes/patients.py`
- `backend/app/routes/reminders.py`
- `backend/app/routes/voice_profiles.py`
- `backend/app/schemas.py`
- `backend/app/services/context_service.py`
- `backend/app/services/llm_service.py`
- `backend/app/services/reminder_service.py`
- `backend/app/services/tone_service.py`
- `backend/app/services/voice_service.py`
- `docs/API_CONTRACTS.md`
- `docs/CURRENT_STATUS_AND_TODO.md`
- `docs/LLAMA_AND_ALEXA_IMPLEMENTATION_NOTES.md`
- `docs/LLM_DYNAMIC_RESPONSE_INTEGRATION.md`
- `docs/TEST_RESULTS_AND_RUNBOOK.md`
- `docs/VOICE_TEAM_NEXT_WEEK_PLAN.md`
- `frontend/app.py`
- `tests/test_llm_service.py`

## Added

- `backend/app/routes/emotion_integration.py`
- `backend/app/services/emotion_integration_service.py`
- `backend/app/time_utils.py`
- `docs/CHANGELOG_THROUGH_2026-10-14.md`
- `docs/REPOSITORY_AUDIT_2026-08-17.md`
- `docs/VOICE_AI_TECHNICAL_HANDOVER_2026-10-14.md`
- `requirements-dev.txt`
- `requirements-preprocessing.txt`
- `requirements-xtts.txt`
- `scripts/verify_xtts.py`
- `tests/test_api_integration.py`
- `tests/test_emotion_integration_service.py`
- `tests/test_reminder_service.py`
- `tests/test_voice_service.py`

## Verification

- Python compile check: passed.
- Automated tests: 22 passed on 2026-10-14.
- Shared optional Python DSP preprocessing merged into the canonical service;
  attribution is recorded in the handover document.
- Substantive tree diff outside `voice-ai-service`: none.
- Generated `.venv`, cache, test temp files, local database, and generated audio
  are excluded from the deliverable ZIP.
